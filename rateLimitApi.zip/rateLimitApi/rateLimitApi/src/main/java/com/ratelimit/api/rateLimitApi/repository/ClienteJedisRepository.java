package com.ratelimit.api.rateLimitApi.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import redis.clients.jedis.Jedis;

@Repository
@RequiredArgsConstructor
public class ClienteJedisRepository implements ClienteCacheRepository {

    private final Jedis jedis=new Jedis();

    private final static String CLIENTE = "cliente";
    private static String keyHash = CLIENTE.concat(":%s");

    @Override
    public Cliente save(Cliente cliente) {
        @SuppressWarnings("unchecked")
		Map<String, String> mapCliente = ((Map<String, String>) this.convertValue(cliente, Map.class));
        this.jedis.hmset(String.format(keyHash, cliente.getKey()),  mapCliente);
        this.jedis.sadd(CLIENTE, cliente.getKey());
        return cliente;
    }
    
    @SuppressWarnings("unchecked")
	public Object convertValue(Object object, Class clazz) {             
       return new ObjectMapper().convertValue(object, clazz);
    }
    
	@Override
	public List<Cliente> findAll() {
        
		Set<String> smembers = this.jedis.smembers(CLIENTE);
        List<Cliente> list = new ArrayList<>();
        
        smembers.forEach(member -> {
            Map<String, String> map = this.jedis.hgetAll(String.format(keyHash, member));
            Cliente product = (Cliente) this.convertValue(map, Cliente.class);
            list.add(product);
        });
        
        return list;

	}
	

	@Override
	public Cliente findByKey(String key) {
		
		Set<String> smembers = this.jedis.smembers(CLIENTE);
        List<Cliente> list = new ArrayList<>();
        
        smembers.forEach(member -> {
            Map<String, String> map = this.jedis.hgetAll(String.format(keyHash, member));
            Cliente client = (Cliente) this.convertValue(map, Cliente.class);
            
            if(client.getKey().equals(key)) {
            	list.add(client);
            }
        });
        
        return ( ! list.isEmpty() ?list.get(0) : null);

	}
	
	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		
	}

}