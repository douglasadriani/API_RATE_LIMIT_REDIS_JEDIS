package com.ratelimit.api.rateLimitApi.interceptor;

public final class Constants {
	
	public static final long QUANTIDADE_SEGUNDOS = 70;
	 
	public static final String RATE_LIMIT_CONTROLLER_INTERCEPTOR = "/cliente/**";
	 
	public static final String PACKAGE_SCAN = "com.poc.rate.limit.rate";
	 
    public static final String HEADER_API_KEY = "key";

    public static final String HEADER_LIMIT_REMAINING = "X-Rate-Limit-Remaining";
    
    public static final String HEADER_RETRY_AFTER = "X-Rate-Limit-Retry-After-Seconds";


}
