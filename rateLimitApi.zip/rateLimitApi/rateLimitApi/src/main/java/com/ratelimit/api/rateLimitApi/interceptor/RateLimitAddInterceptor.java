package com.ratelimit.api.rateLimitApi.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication(scanBasePackages = "com.ratelimit.api.rateLimitApi", exclude = { 
        DataSourceAutoConfiguration.class,
        SecurityAutoConfiguration.class
})
public class RateLimitAddInterceptor implements WebMvcConfigurer {
    
	@Autowired
    @Lazy
    private RateLimitInterceptor interceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
    	registry.addInterceptor(interceptor).addPathPatterns(Constants.RATE_LIMIT_CONTROLLER_INTERCEPTOR);
        
    }
    
}
