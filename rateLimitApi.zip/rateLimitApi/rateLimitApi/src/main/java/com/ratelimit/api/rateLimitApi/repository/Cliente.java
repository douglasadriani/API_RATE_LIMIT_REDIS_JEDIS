package com.ratelimit.api.rateLimitApi.repository;

public class Cliente {
	private String dateTimeInicio;
	private String capacidadeTotal;
	private String consumo;
	private String key;
	public String getDateTimeInicio() {
		return dateTimeInicio;
	}
	public void setDateTimeInicio(String dateTimeInicio) {
		this.dateTimeInicio = dateTimeInicio;
	}
	public String getCapacidadeTotal() {
		return capacidadeTotal;
	}
	public void setCapacidadeTotal(String capacidadeTotal) {
		this.capacidadeTotal = capacidadeTotal;
	}
	public String getConsumo() {
		return consumo;
	}
	public void setConsumo(String consumo) {
		this.consumo = consumo;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	
}
