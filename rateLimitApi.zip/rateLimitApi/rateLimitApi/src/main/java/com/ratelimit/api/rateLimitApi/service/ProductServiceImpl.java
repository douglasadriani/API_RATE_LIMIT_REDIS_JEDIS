package com.ratelimit.api.rateLimitApi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ratelimit.api.rateLimitApi.repository.Cliente;
import com.ratelimit.api.rateLimitApi.repository.ClienteCacheRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ClienteService {

    @Autowired
    private ClienteCacheRepository productCacheRepository;

    public Cliente save(Cliente product) {
        return this.productCacheRepository.save(product);
    }

    @Override
    public List<Cliente> findAll() {
        return this.productCacheRepository.findAll();
    }

    @Override
    public void delete(String id) {
        this.productCacheRepository.deleteById(id);
    }

	@Override
	public Cliente findByKey(String key) {
		return this.productCacheRepository.findByKey(key);
	}

}
