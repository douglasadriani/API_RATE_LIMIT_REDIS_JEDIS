package com.ratelimit.api.rateLimitApi.interceptor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.ratelimit.api.rateLimitApi.repository.Cliente;
import com.ratelimit.api.rateLimitApi.service.ClienteService;

@Component
public class RateLimitInterceptor implements HandlerInterceptor {
	
	private static final int NUM_ITENS_CONSUMIDOS = 1;
	
	public static int CAPACIDADE =5;
	public static long TEMPO =60;
    
	@Autowired
	private ClienteService service;
    
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String apiKey = request.getHeader(Constants.HEADER_API_KEY);

        if (apiKey == null || apiKey.isEmpty()) {
            response.sendError(HttpStatus.BAD_REQUEST.value(), "Missing Header: " + Constants.HEADER_API_KEY);
            return false;
        }
    
        Cliente cliente = obtemCliente(apiKey);
		
		if( verificaDentroLimiteTempo(cliente) ) {
			
			if(verificaCapacidadeConsumoDisponivel(cliente)) {
				
				//Neste caso esta dentro do tempo e tem capacidade de consumo, somente atualiza o bucket com o novo dado de consumo
				consomeItemBucket(cliente);
			
				System.out.println("SUCESSO");
				
				return true;
				
			}else {
				
				//neste caso não tem capacidade de consumo
				System.out.println("ERRO 429");
				return false;
			}
			
		}else {
			
			//Neste caso ja passou mais do que o tempo configurado, então inserimos o cliente no bucket com as novas caracteristicas
			Cliente clienteAtualizado = createCliente(apiKey);
			//bucket.put(createCliente.getKey(), createCliente);
			service.save(clienteAtualizado);
			return true;
		}
	
   }
    
	
	private void consomeItemBucket(Cliente cliente) {
		
		cliente.setConsumo(String.valueOf(Integer.valueOf(cliente.getConsumo())+1));
		service.save(cliente);
		
	}

	private boolean verificaCapacidadeConsumoDisponivel(Cliente cliente) {
		
		return Integer.valueOf(cliente.getConsumo()) < Integer.valueOf(cliente.getCapacidadeTotal());
	}

	private boolean verificaDentroLimiteTempo(Cliente cliente) {
	
		LocalDateTime horaAnteriorFormatado = LocalDateTime.parse(cliente.getDateTimeInicio(), DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
		System.out.println("Horario Inicio: " + horaAnteriorFormatado);

		String horarioAtual = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));       
        LocalDateTime horarioAtualFormatado = LocalDateTime.parse(horarioAtual, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        System.out.println("Horario Ataul: " + horarioAtualFormatado);
        
        long segundos = ChronoUnit.SECONDS.between(horaAnteriorFormatado, horarioAtualFormatado);
        
        System.out.println("Diferença em Segundos: " + segundos);
    
		return (segundos<=TEMPO);
	}

	private Cliente obtemCliente(String key) {
		
		Cliente cliente = service.findByKey(key);
		if(cliente==null) {
			cliente = service.save(createCliente(key));
		}
		
		return cliente;
	}

	private Cliente createCliente(String key) {
		
		Cliente cliente = new Cliente();
		cliente.setKey(key);
		cliente.setCapacidadeTotal(String.valueOf(CAPACIDADE));
		cliente.setConsumo(String.valueOf(NUM_ITENS_CONSUMIDOS));        
        cliente.setDateTimeInicio(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
		
        return cliente;
	}

}